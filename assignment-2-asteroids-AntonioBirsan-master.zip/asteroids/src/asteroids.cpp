/* Asteroids
   Asteroids game using MVC 
	 w15004625
	 Antonio Birsan
*/

/* C libraries */
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>

/* hardware platform libraries */

#include <display.h>
#include <mbed.h>


/* Main game elements */
#include "model.h"
#include "view.h"
#include "controller.h"

/* Game state */
float elapsed_time; 
int   score;
int   lives;
struct ship player;
bool inPlay;

float Dt = 0.01f;

Ticker model, view, controller, asteroid;

bool paused = true;
/* The single user button needs to have the PullUp resistor enabled */
DigitalIn userbutton(P2_10,PullUp);
int main()
{
		initMissileHeap();
		initrockHeap();
    init_DBuffer();
    initGame(&player);

    view.attach( draw, 0.025);
    model.attach( physics, Dt);
    controller.attach( controls, 0.1);
		asteroid.attach(rockSystem, 0.1);
    
	/* Pause to start */
    
   while(1) {
					while(inPlay && lives!=0){
						elapsed_time += 1;
					}
          if(lives==0){
					view.detach();
					model.detach();
					controller.detach();
					asteroid.detach();
					gameOver();	
				}
				if(restart()){
					view.attach( draw, 0.025);
					model.attach( physics, Dt);
					controller.attach( controls, 0.1);
					asteroid.attach(rockSystem, 0.1);
					initGame(&player);
				}
					wait_ms(200);
    }
}
