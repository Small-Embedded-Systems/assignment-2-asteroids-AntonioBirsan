/* Asteroids View */


/* support double buffering */
void init_DBuffer(void);
void swap_DBuffer(void);
void gameOver(void);
void drawMissiles(struct missile *lst);
void drawShip(struct ship *lst);
void drawrocks(struct rock* lst);
void drawAsteroids(struct rock *lst);
void draw(void);
