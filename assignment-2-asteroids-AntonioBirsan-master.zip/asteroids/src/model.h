/* Asteroids Model */
 struct point {
    float x,y;
};
typedef struct point coordinate_t;
typedef struct point vector_t;

extern float headingRadians;

typedef struct ship {
	int heading;
	coordinate_t p;
	vector_t     v;
	coordinate_t a;
	coordinate_t c;
	coordinate_t b;
	double   accel;
	int shield;
}ship_t;


typedef struct rock {
	coordinate_t p;
	vector_t v;
	int height;
	int width;
	float duration;
	struct rock *next;
}rock_t;


typedef struct missile {
    coordinate_t p;
		vector_t     v;
		float duration;
    struct missile *next;
}missile_t;

extern struct missile *shots;
extern struct rock *rocks;

void initMissileHeap(void);
void initrockHeap(void);
void strike( missile_t *m);
void rockStrike(rock_t *r);
void collisionThree(missile_t *m, rock_t *r);
void wrapAround(ship_t *lst);
void initGame(ship_t *lst);
void updateShip(ship_t *lst);
void missileUpdate(missile_t *l);
void rockUpdate(rock_t *l);
void collisionFour(rock_t *r, ship_t *s);
void freeNode(missile_t *n);
void rockFreeNode(rock_t *n);
void collision(missile_t *m, rock_t *r);
void newLife(ship_t *lst);
missile_t *allocNode(void);
rock_t *rockAllocNode(void);
void missileSystem(void);
void rockSystem(void);
void physics(void);
