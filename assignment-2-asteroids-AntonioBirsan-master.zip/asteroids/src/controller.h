void controls(void);
bool restart(void);
bool isPressed(enum position p);