/* Controller */

/* C libraries */
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>

/* hardware platform libraries */
#include <mbed.h>
#include <display.h>

/* asteroids */
#include "model.h"
#include "asteroids.h"
#include "controller.h"

/* Joystick 5-way switch
*/
enum position { left,down,right,up,centre };
DigitalIn joystick[] = {P5_0, P5_1, P5_4, P5_2, P5_3};


void controls(void){
	if(isPressed(left)) player.heading += 12;
	else if(isPressed(right)) player.heading -= 12;
	else if(isPressed(up)){
		if( player.accel  < 2) {
			player.accel += 0.1;
		}
	}else if(isPressed(down)){
		if(player.accel > -2) {
			player.accel -=0.1;
		}
	} else if(isPressed(centre)) missileSystem();
}

bool isPressed(enum position p) {
	return !joystick[p];
}

bool restart(void) {
	if(isPressed(centre) && lives == 0){
		return true;
	}
	return false;
}
