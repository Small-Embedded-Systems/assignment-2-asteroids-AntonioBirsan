/* Game state */

extern float elapsed_time; /* time this ship has been active */
extern int   score;        /* total score so far */
extern int   lives;        /* lives remaining */
extern bool inPlay;
extern struct ship player;

extern const float Dt; /* Time step for physics, needed for consistent motion */
