/* Asteroids model */
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>

#include "model.h"
#include "utils.h"
#include "asteroids.h"

static missile_t *freeNodes;
static rock_t *rockFreeNodes;
static const int rockHeapSize = 10;
static const int heapSize = 6;
static missile_t heap[heapSize];
static rock_t rockHeap[rockHeapSize];
struct missile *shots;
struct rock *asteroids;
struct rock *rocks;

float headingRadians;




void newLife(ship_t *lst){
	lst->p.x = 240;
	lst->p.y = 130;
	lst->heading = randrange(0,360);
	lst->shield = 100;
	score += (elapsed_time) / 1000000;
	elapsed_time = 0.0;
	inPlay = true;
	
}



void collisionFour(rock_t *r, ship_t *s){
	for( ; r ; r = r->next){
				float distX = fabsf(s->p.x + 8 - r->p.x - 18);
				float distY = fabsf(s->p.y + 8  - r->p.y - 18);
		
				if(distX <= 18 && distY <= 18){
					
					if(s->shield > 1){
						if(lives != 0){
						s->shield -=25;
						r->duration = 0;
						}
					}
					else if(s->shield <= 0){
						r->duration = 0;
						if(lives != 0){
						lives--;
						inPlay = false;
						newLife(&player);
						}
					}
					
				}
			}

	}


void missileUpdate(struct missile *l){
	for( ; l ; l = l->next){
		l->p.x += l->v.x * Dt;
		l->p.y += l->v.y * Dt;
		if(l->p.x<-20 || l->p.x > 500) l->duration =0;
		if(l->p.y<25 || l->p.y > 280) l->duration =0;
		l->duration -=Dt;
		if(l->next->duration <= 0){
			missile_t *expired = l->next;
			l->next = l->next->next;
			freeNode(expired);
		}
	}
}



void collisionThree(missile_t *m, rock_t *r){
	for( ; m ; m = m->next){
		for( struct rock *rock = r ; rock ; rock = rock->next){
				
				float distX = fabsf(m->p.x  - rock->p.x - 15);
				float distY = fabsf(m->p.y  - rock->p.y - 15);
				
				if(distX <= 15 && distY <= 15){
					m->duration = 0;
					rock->duration = 0;
				}	
		}
	}	
}



void freeNode(missile_t *n){
	n->next = freeNodes;
	freeNodes = n;
}

void rockFreeNode(rock_t *n){
	n->next = rockFreeNodes;
	rockFreeNodes = n;
}


void rockUpdate(rock_t *l){
	for( ; l ; l = l->next){
		l->p.x += l->v.x * Dt;
		l->p.y += l->v.y * Dt;
		if(l->p.x<-20 || l->p.x > 500) l->duration =0;
		if(l->p.y<25 || l->p.y > 280) l->duration =0;
		l->duration -=Dt;

		if(l->next->duration <= 0){
			rock_t *expired = l->next;
			l->next = l->next->next;
			rockFreeNode(expired);
		}
	} 
}


void updateShip(ship_t *lst){
	headingRadians = radians(lst->heading);
	
	lst->a.x = 10 * (cos(headingRadians));
	lst->a.y = 10 * (sin(headingRadians));
	lst->b.x = (-5*(cos(headingRadians))) - (5*(sin(headingRadians)));
	lst->b.y = (-5*(sin(headingRadians))) + (5*(cos(headingRadians)));
	lst->c.x = (-5*(cos(headingRadians))) - (-5*(sin(headingRadians)));
	lst->c.y = (-5*(sin(headingRadians))) + (-5*(cos(headingRadians)));
	lst->p.x  += lst->v.x * (cos(headingRadians));
	lst->p.y  += lst->v.y * (sin(headingRadians));
	
}

void initGame(ship_t *lst){
	lst->p.x = 240;
	lst->p.y = 130;
	lst->heading = randrange(0,360);
	lst->shield = 100;
	score = 0;
	elapsed_time = 0.0;
	lives = 5;
	inPlay = true;

	
}

void wrapAround(ship_t *lst){
	if(lst->p.x > 480) lst->p.x = 5;
	else if(lst->p.x < 0) lst->p.x = 475;
	else if(lst->p.y > 260) lst->p.y = 30;
	else if(lst->p.y < 30) lst->p.y = 255;
}

void rockStrike(rock_t *r){
	r->p.x = randrange(0, 470);
	r->p.y = randrange(20,230);
	r->v.x = randrange(-20,20);
	r->v.y = -randrange(15, 25);
	r->duration = randrange(900,1100);
}

void strike( missile_t *m){
	m->p.x = player.p.x;
	m->p.y = player.p.y;
	m->v.x = 250 * (cos(headingRadians));
  m->v.y = 250 * (sin(headingRadians));
	m->duration = 200;
}

void initMissileHeap(void){
	int n;
	for( n = 0; n<(heapSize-1); n++){
		heap[n].next = &heap[n+1];
	}
	heap[n].next = NULL;
	freeNodes = &heap[0];
}


void initrockHeap(void){
	int n;
	for(n = 0; n<(rockHeapSize-1); n++){
		rockHeap[n].next = &rockHeap[n+1];
	}
	rockHeap[n].next = NULL;
	rockFreeNodes = &rockHeap[0];
}

missile_t *allocNode(void){
	missile_t *node = NULL;
	if(freeNodes) {
		node = freeNodes;
		freeNodes = freeNodes->next;
	}
	return node;
}


rock_t *rockAllocNode(void){
	rock_t *node = NULL;
	if(rockFreeNodes){
		node = rockFreeNodes;
		rockFreeNodes = rockFreeNodes->next;
	}
	return node;
}

void missileSystem(void){
	struct missile *spark = allocNode();
	if(spark){
		spark->next = shots;
		shots = spark;
		strike(spark);
	}
}


void rockSystem(void){
	struct rock *spark = rockAllocNode();
	if(spark) {
		spark->next = rocks;
		rocks = spark;
		rockStrike(spark);
	}
}

void physics(void)
{
	
		
    wrapAround(&player);
		missileUpdate(shots);
		rockUpdate(rocks);
		wrapAround(&player);
		updateShip(&player);
		collisionFour(rocks, &player);
	  collisionThree(shots, rocks);
		if((player.v.x < 5 && player.v.y < 5 )
			|| (player.v.x > -5 && player.v.y > -5)) {
			player.v.x += player.accel;
			player.v.y += player.accel;
		}
		if(player.accel > 0) {
			 player.accel -= 0.01f;
		}
		if(player.accel < 0) {
			player.accel += 0.01f;
		}
		if(player.v.x > 0 && player.v.y > 0) {
			 player.v.x -= 0.01f;
			 player.v.y -= 0.01f;
		}
		
		if(player.v.x < 0 && player.v.y < 0) {
			 player.v.x += 0.01f;
			 player.v.y += 0.01f;
		}
		
		if(player.v.x == 0 || player.v.y == 0) {
			 player.v.x = 0.00f;
			 player.v.y = 0.00f;
		}

}

